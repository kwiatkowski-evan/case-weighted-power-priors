RenextEnvir <- new.env()
assign(".RLlegend", RLlegend.ini(), envir = RenextEnvir)
